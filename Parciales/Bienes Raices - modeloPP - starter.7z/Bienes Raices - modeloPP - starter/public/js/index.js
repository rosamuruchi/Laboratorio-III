window.onload = function()
{
    frm = document.forms[0];
    let tabla = document.getElementById("divTabla");
    let divBotontes = document.getElementById("divBotones");
    let btnAlta = document.getElementById("btnAlta");
    let xhr = new XMLHttpRequest();

    //Levanto tabla de data.json
    traerAnuncios(xhr, tabla);

    //Modificacion y alta de anuncio
    frm.onsubmit = function(event)
    {
        if(btnAlta.value == "Modificar Anuncio")
        {
            event.preventDefault();
            let data = obtenerAnuncio(event.target);
            console.log(data);
            let newData = {id: document.getElementById("txtId").value, ...data};
            newData.active = true;
            console.log(newData);
            xhr.onreadystatechange = function()
            {
                if(xhr.readyState == 4){
                    if(xhr.status == 200){
                        console.log('Modificación correcta');
                        traerAnuncios(xhr, tabla);
                        frm.reset();
                    }
                    else{
                        console.log(`Error: ${xhr.status} - ${xhr.statusText}`);
                    }
                }
                else{
                    tabla.innerHTML = '<img src="./img/load.gif" alt="loading" />';
                }
            }
            xhr.open('POST', '/modificarAnuncio', true);
            xhr.setRequestHeader('Content-type', 'application/json;charset=UTF-8');
            xhr.send(JSON.stringify(newData));
        }
        else{
            event.preventDefault();
            let data = obtenerAnuncio(event.target);
            console.log(data);
            xhr.onreadystatechange = function(){
                if(xhr.readyState == 4){
                    if(xhr.status == 200){
                        console.log('Alta correcta');
                        traerAnuncios(xhr, tabla);
                    }
                    else{
                        console.log(`Error: ${xhr.status} - ${xhr.statusText}`);
                    }
                }
                else{
                    tabla.innerHTML = '<img src="./img/load.gif" alt="loading" />';
                }
            }
            xhr.open('POST', '/altaAnuncio', true);
            xhr.setRequestHeader('Content-type', 'application/json;charset=UTF-8');
            xhr.send(JSON.stringify(data));
        }
    }
    
    //Agrego eventos para los clicks en la tabla
    tabla.addEventListener('click', function(event) {
        const row = event.target.parentNode;
        console.log(row);
        var cols = row.getElementsByTagName("td");
        document.getElementById("txtId").value = cols[0].innerText;
        document.getElementById("txtTitulo").value = cols[1].innerText;
        if(cols[2].innerText == "Venta"){
            document.getElementById("rdoVenta").checked = true;
        }
        else{
            document.getElementById("rdoAlquiler").checked = true;
        }

        
        /*let cadena = cols[4].innerText;
        if(cadena.indexOf('EUR') != -1)
        {
            document.getElementById("euro").checked = true;
        }
        else if(cadena.indexOf('ARS') != -1)
        {
            document.getElementById("ars").checked = true;
        }
        else
        {
            document.getElementById("dolar").checked = true;
        }*/
        
        document.getElementsByName("transaccion").value = cols[2].innerText;
        document.getElementById("txtDesc").value = cols[3].innerText;
        document.getElementById("txtPrecio").value = parseInt(cols[4].innerText);
        document.getElementById("numBaños").value = cols[5].innerText;
        document.getElementById("numGarages").value = cols[6].innerText;
        document.getElementById("numDormitorios").value = cols[7].innerText;
        

        var btnEliminar = document.createElement("input");
        btnEliminar.setAttribute('style', 'display: inline-block;');
        btnEliminar.setAttribute('type', 'submit');
        btnEliminar.setAttribute('value', 'Eliminar');
        btnEliminar.setAttribute('id', 'btnEliminar');

        var btnCancelar = document.createElement("input");
        btnCancelar.setAttribute('value', 'Cancelar');
        btnCancelar.setAttribute('type', 'submit');
        btnCancelar.setAttribute('style', 'float: right;');
        btnCancelar.setAttribute('id', 'btnCancelar');

        divBotontes.innerHTML = "";
        btnAlta.setAttribute('value', 'Modificar Anuncio');
        divBotontes.appendChild(btnEliminar);
        divBotontes.appendChild(btnCancelar);

        btnCancelar.addEventListener('click', function(event){
            frm.reset();
            divBotontes.innerHTML = "";
            btnAlta.setAttribute('value', 'Alta Anuncio');
        });

        btnEliminar.addEventListener('click', function(event)
        {
            xhr.onreadystatechange = function()
            {
                if(xhr.readyState == 4){
                    if(xhr.status == 200){
                        console.log('Baja correcta');
                        traerAnuncios(xhr, tabla);
                        frm.reset();
                    }
                    else{
                        console.log(`Error: ${xhr.status} - ${xhr.statusText}`);
                    }
                }
                else{
                    tabla.innerHTML = '<img src="./img/load.gif" alt="loading" />';
                }
            }
            xhr.open('POST', '/bajaAnuncio', true);
            xhr.setRequestHeader('Content-type', 'application/json;charset=UTF-8');
            var data = {id : cols[0].innerText};
            xhr.send(JSON.stringify(data));
        });
    });
}