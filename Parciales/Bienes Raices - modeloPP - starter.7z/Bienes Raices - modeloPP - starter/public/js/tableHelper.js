function crearTabla(array) {
    var tabla = document.createElement("table");
    tabla.setAttribute('border','1px solid black');
    tabla.setAttribute('style','border-collapse :collapse');
    tabla.setAttribute('width','700px');

    let cabecera = document.createElement("tr");

    tableHeaders.forEach(function(element){
        let th = document.createElement("th");
        th.textContent = element;
        cabecera.appendChild(th);
    });

    tabla.appendChild(cabecera);

    for(var i in array) 
    {
        let fila = document.createElement("tr");
        let objeto = array[i];

        for(j in objeto)
        {
            let celda = document.createElement("td");
            celda.setAttribute('style','text-align : center');
            let dato;

            if(j != 'active'){
                dato = document.createTextNode(objeto[j]);
                celda.appendChild(dato);
                fila.appendChild(celda);
            }
        }
        tabla.appendChild(fila);
    }
    return tabla;
}