let anuncios = [];
var frm;
var tableHeaders = ['ID', 'Título', 'Transacción', 'Descripción', 'Precio', 'Baños', 'Estacionamientos', 'Dormitorios'];

function Anuncio(titulo, transaccion, descripcion, precio, num_wc, num_estacionamiento, num_dormitorio) {
    this.titulo = titulo;
    this.transaccion = transaccion;
    this.descripcion = descripcion;
    this.precio = precio;
    this.num_wc = num_wc;
    this.num_estacionamiento = num_estacionamiento;
    this.num_dormitorio = num_dormitorio;
    
}

function obtenerAnuncio(frm) 
{
    let titulo;
    let descripcion;
    let transaccion;
    let precio;
    let dormitorios;
    let baños;
    let estacionamiento;
    let moneda;

    for (elemento of frm.elements) {

        switch (elemento.name) {
            case "titulo":
                titulo = elemento.value;
                break;
            case "descripcion":
                descripcion = elemento.value;
                break;
            case "transaccion":
                if (elemento.checked) {
                    transaccion = elemento.value;
                }
                break;
            case "moneda":
                moneda=elemento.value;
                break;
            case "precio":
                precio = elemento.value + moneda;
                break;
            case "dormitorios":
                dormitorios = elemento.value;
                break;
            case "baños":
                baños = elemento.value;
                break;
            case "estacionamiento":
                estacionamiento = elemento.value;
                break;
        }
    }
    return new Anuncio(titulo, transaccion, descripcion, precio, baños, estacionamiento, dormitorios);
}

function traerAnuncios(xhr, tabla)
{
    xhr.onreadystatechange = function(){
        if(xhr.readyState == 4){
            if(xhr.status == 200){
                let anuncios = JSON.parse(xhr.responseText);
                tabla.innerHTML = "";
                tabla.appendChild(crearTabla(anuncios.data));
            }
            else{
                console.log(`Error: ${xhr.status} - ${xhr.statusText}`);
            }
        }
        else{
            tabla.innerHTML = '<img src="./img/load.gif" alt="loading" />';
        }
    }
    xhr.open('GET', '/traerAnuncios', true);
    xhr.send();
}

